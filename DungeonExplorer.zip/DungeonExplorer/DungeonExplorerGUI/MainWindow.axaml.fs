type MainWindow() as this =
    inherit Window()
    do
        this.InitializeComponent()

        let logBox = this.FindControl<TextBox>("GameLog")
        let exploreBtn = this.FindControl<Button>("ExploreButton")
        let inventoryBtn = this.FindControl<Button>("InventoryButton")
        let useItemBtn = this.FindControl<Button>("UseItemButton")

        let appendLog (msg: string) =
            logBox.Text <- logBox.Text + msg + "\n"

        let player = createPlayer() // From your existing code

        exploreBtn.Click.Add(fun _ ->
            // Generate a room and describe it
            let room = generateRoom()
            match room with
            | Empty -> appendLog "The room is empty."
            | Treasure item ->
                appendLog "You found a treasure!"
                player.Inventory.Add(item)
            | _ -> appendLog "More room types coming soon..."
        )

        inventoryBtn.Click.Add(fun _ ->
            appendLog "Inventory:"
            player.Inventory
            |> Seq.iter (fun item -> appendLog (sprintf "- %A" item))
        )

        useItemBtn.Click.Add(fun _ ->
            appendLog "Using items not implemented yet."
        )

    member private this.InitializeComponent() =
        AvaloniaXamlLoader.Load(this)
